//
//  SideViewController.swift
//  MAD Project 1
//
//  Created by Robin Obregon on 1/21/24.
//

import UIKit

class SideViewController: UIViewController {
    
    var section : Section?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let section = section {
            sectionImage.image = section.image
            sectionImage.contentMode = .scaleAspectFill
            sectionDesc.text = section.desc
            sectionDesc.numberOfLines = 0
            sectionDesc.lineBreakMode = .byWordWrapping
            sectionDesc.frame.size.width = 275
            sectionDesc.sizeToFit()
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBOutlet weak var sectionImage: UIImageView!
    @IBOutlet weak var sectionDesc: UILabel!
}
