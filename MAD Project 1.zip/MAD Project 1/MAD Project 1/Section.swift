//
//  Section.swift
//  MAD Project 1
//
//  Created by Robin Obregon on 1/21/24.
//

import UIKit

struct Section {
    
    let image: UIImage
    let desc: String
    
}
