//
//  MainViewController.swift
//  MAD Project 1
//
//  Created by Robin Obregon on 1/21/24.
//

import UIKit

class MainViewController: UIViewController {
    
    let college = Section(image: UIImage(named: "FIU")!, desc: "I am a senior at FIU studying computer science. I am a member of INIT and have a GPA of 3.81. I took this class because I was interested in learning about app development.")
    let sports = Section(image: UIImage(named: "WaterPolo")!, desc: "I have played water polo since I was 10 years old. I played 4 years of varsity high school water polo, 2 of which I was captain. I have also participated in college club water polo here at FIU.")
    let interests = Section(image: UIImage(named:"Chill")!, desc: "I have many interests like gaming, playing basketball, learning new technologies, etc. I would definitely have to say my favorite thing to do is relax and chill with my girlfriend and our cat.")
    
    var sections : [Section] = []
    
    @IBOutlet weak var profileImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        sections = [college, sports, interests]
        
        title = "About Me"
        profilePic.image = UIImage(named:"RobinObregon")
        profilePic.clipsToBounds = true
        profilePic.contentMode = .scaleAspectFit
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    @IBOutlet weak var profilePic: UIImageView!
    
    @IBAction func didTapButton(_ sender: UITapGestureRecognizer) {
        if let tappedView = sender.view {
            performSegue(withIdentifier: "detailSegue", sender: tappedView)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        
        if segue.identifier == "detailSegue",
           let tappedView = sender as? UIView,
           let sideViewController = segue.destination as? SideViewController{
            
            if tappedView.tag == 0{
                sideViewController.section = sections[0]
            } else if tappedView.tag == 1{
                sideViewController.section = sections[1]
            } else if tappedView.tag == 2{
                    sideViewController.section = sections[2]
                } else {
                    print("No section was selected. Please check again.")
                }
                
            }
            
        }
    }
